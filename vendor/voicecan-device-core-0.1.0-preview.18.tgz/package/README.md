# VoiceCan Private Device Core

Private source repository for the frozen V1.2 device protocol. It owns the Rust codec/state machine, Golden Fixtures, Browser/Node WASM generation, conformance checks, and the release source for `@voicecan/device-core`.

The source repository must remain access-controlled. Its npm artifact is intentionally narrower: semantic APIs, type declarations, compiled WASM, loaders, and a release manifest only. It must never contain Rust sources, fixtures, source maps, raw-command APIs, SID/CID documentation, or debug symbols. Preview artifacts are checksummed and content-inspected; do not call them signed until signing and provenance attestations are actually enabled.

## Build and verify

```powershell
npm install
npm run build
npm test
cargo fmt --all -- --check
cargo test --workspace
cargo clippy --workspace --all-targets -- -D warnings
```

`npm run package` creates `voicecan-device-core-<version>.tgz`. Publish that exact reviewed artifact or import it into the public Device Platform vendor directory. Never build private protocol sources inside the public repository or its CI.
