# VoiceCan Private Device Core

Private source repository for the frozen V1.2 device protocol. It owns the Rust codec/state machine, Golden Fixtures, Browser/Node WASM generation, conformance checks, and the release source for `@voicecan/device-core`.

The source repository must remain access-controlled. Its npm artifact is intentionally narrower: semantic APIs, type declarations, compiled WASM, loaders, and a release manifest only. It must never contain Rust sources, fixtures, source maps, raw-command APIs, SID/CID documentation, or debug symbols. Preview artifacts are checksummed and content-inspected; do not call them signed until signing and provenance attestations are actually enabled.

## Build and verify

```powershell
npm install
npm run build
npm test
cargo fmt --all -- --check
cargo test --workspace
cargo clippy --workspace --all-targets -- -D warnings
```

`npm run package` creates `voicecan-device-core-<version>.tgz`. Publish that exact reviewed artifact or import it into the public Device Platform vendor directory. Never build private protocol sources inside the public repository or its CI.

## Native preview SDK

`crates/device-runtime` is a synchronous Rust reducer for imported-credential and explicitly backed-up local-binding sessions: pre-auth identity/compatibility check, handshake, authenticated identity verification, status/battery/storage reads. It owns frame aggregation, a single pending command, write/response ordering, command deadlines and epoch fencing. It does not generate credentials or expose mutation/OTA/file operations.

`crates/device-native` uses pinned UniFFI 0.31.0 for Swift/Kotlin semantic bindings. Only this FFI boundary uses generated unsafe scaffolding; the runtime and protocol crates forbid unsafe code.

```sh
python3 scripts/build-native.py
# With JDK/Android SDK configured; use a Gradle 8.14.4 installation:
gradle -p native/android :sdk:assembleRelease
# After tests/content review and committing the source:
python3 scripts/export-native.py /path/to/device-mobile
```

Set `ANDROID_NDK_HOME` if NDK 28.2.13676358 is elsewhere. Required Rust targets: aarch64-apple-ios, aarch64-apple-ios-sim, x86_64-apple-ios, aarch64-linux-android, x86_64-linux-android. Android minimum API 29; iOS minimum 17.0. Android outputs arm64-v8a/x86_64, with 16 KiB ELF page alignment. Native binaries and temporary headers live under ignored target/; the private Gradle module packages generated bindings and binary libraries only.

Export pins source revision, conformance fixture digest and each file checksum. This is an unsigned preview, not a signed/proven production SDK. Actual firmware pre-auth identity behavior and imported-token handshake behavior still require hardware verification. The mobile client must persist/read back imported credentials before starting the runtime because some unbound firmware can write credentials during handshake.

### Local binding contract (native SDK 0.1.0-preview.3)

The exported AAR keeps the filename `voicecan-native-0.1.0-preview.1.aar` for existing Gradle references. `sdk-lock.json` carries the actual SDK version `0.1.0-preview.3` and checksums; the mobile verifier validates the inventory and digests without pinning that filename to a semantic version. Replace the generated bindings and binaries together.

Generated Swift APIs (the last two are methods of `NativeSession`):

```swift
inspectAdvertisement(manufacturerData: Data) -> AdvertisementIdentity?
startInspection(epoch: UInt64, expectedSerial: String, platform: UInt8, nowMs: UInt64) -> SessionUpdate
startLocalBinding(epoch: UInt64, tokenHex: String, expectedSerial: String, platform: UInt8, nowMs: UInt64, backupVerified: Bool) -> SessionUpdate
```

Kotlin equivalents in `com.voicecan.sdk`:

```kotlin
fun inspectAdvertisement(manufacturerData: ByteArray): AdvertisementIdentity?
fun startInspection(epoch: ULong, expectedSerial: String, platform: UByte, nowMs: ULong): SessionUpdate
fun startLocalBinding(epoch: ULong, tokenHex: String, expectedSerial: String, platform: UByte, nowMs: ULong, backupVerified: Boolean): SessionUpdate
```

`AdvertisementIdentity` is a UniFFI record with `serial: String` and `bound: Bool` (Kotlin `Boolean`). Pass iOS manufacturer `Data` directly. Android must prepend the company identifier as two little-endian bytes to its manufacturer-specific data. Unknown vendor, wrong total/SN length, invalid UTF-8, control characters and invalid bound flags return nil/null. Protocol bytes and malformed-payload fixtures belong only in this private Core, never in mobile tests.

`SessionStage.identityReady` (Kotlin `IDENTITY_READY`) is appended to the stage enum. Existing cases keep their ordering, and existing native methods remain available. Hosts with exhaustive stage switches must add the new case. Inspection emits only the device-info query and stops after the exact expected serial is verified. The completion carries identity, no status, no write and `disconnect == false`; it is not an authenticated `Ready` session. The host closes the inspection transport. Unsolicited handshake responses cannot authenticate inspection, and refresh cannot promote it.

The host must freshly inspect the selected peripheral's advertisement and require unbound before creating a new pending binding, then obtain actual device identity through `startInspection` before creating that pending record. It owns token creation, durable persistence/readback, external backup and strict backup verification. Recheck a fresh unbound advertisement before the first local connection. Persist/read back the binding-attempt marker before calling `startLocalBinding` with the same stored token and `backupVerified: true`. A false backup attestation fails with `BACKUP_NOT_VERIFIED` without a transport write. Core cannot independently verify host storage or external backup.

Local binding checks the exact device serial before authentication just like imported sessions. An unactivated device stores the first token; an already activated device accepts only its stored token and rejects a mismatch without overwriting it. Recovery can therefore use the same durably stored token even when the device now advertises bound. Never generate a replacement token on recovery, silently overwrite credentials, or infer authentication from an advertisement or `IdentityReady`. Use a strictly increasing epoch for each new connection; stale starts and callbacks cannot restart a session. Physical-device behavior still requires hardware verification.

Native sessions do not use model or firmware version allowlists. Those fields are display metadata, including empty version values; they are not authentication evidence. Serial matching, frame validation, backup requirements and Token authentication remain enforced. The standalone Browser/Node compatibility report remains unchanged.
